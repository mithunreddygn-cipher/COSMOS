# Existing design system

## Typography

- Interface: IBM Plex Sans.
- Scientific values, IDs, timestamps and metadata: IBM Plex Mono.
- Decorative/editorial serif typography is not part of the current direction.

## Palette

The current CSS uses near-black voids with cool blue/cyan accents, restrained violet and amber status colors, and muted slate text.

| Role | Current token/examples |
|---|---|
| Void | `#030508`, later refined toward `#05070a` |
| Surface | `#0b1019`, `#0e141c`, `#121a23` |
| Primary text | `#e9f0f7`, `#edf3f7` |
| Muted text | `#91a2b6`, `#778896` |
| Accent | `#6de7e5`, `#76d8d0` |
| Violet | `#aa9cff` / restrained atmospheric purple |
| Warning/untestable | `#f1b86d`, `#f0bd73` |
| Borders | translucent cool white/blue lines |

## Existing components

Sidebar with grouped navigation and collapse state; status pills; progress tracker; scientific panels; metadata bars; result rows; explorer controls; image/chart stages; evidence/hypothesis panels; report download links; empty and warning states.

## Imagery

The current frontend includes supplied visual assets in `frontend/public/assets/`:

- `cosmos-starfield.png` — global atmospheric background.
- `cosmos-hero-planet.png` — entry hero composition.
- `cosmos-galaxy.png` — observation exploration surface.

These are decorative/illustrative assets, not scientific observations. Scientific FITS previews remain API-derived.

## Layout principles to preserve

Near-black workspace, readable scientific surfaces, progressive disclosure, visible provenance, reduced-motion handling, responsive sidebar/navigation, and explicit scientific status labels. Do not turn charts or FITS data into decorative imagery.
