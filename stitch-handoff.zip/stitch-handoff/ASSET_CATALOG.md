# Asset catalog

## Frontend visual assets

| Asset | Path | Use | Scientific status |
|---|---|---|---|
| Deep-space nebula/starfield | `frontend/public/assets/cosmos-starfield.png` | Global atmospheric background | Decorative supplied artwork; not observation data |
| Cyan-rimmed planet | `frontend/public/assets/cosmos-hero-planet.png` | Mission Control entry hero | Decorative supplied artwork; not a planet observation |
| Whirlpool galaxy | `frontend/public/assets/cosmos-galaxy.png` | Observation exploration surface | Decorative supplied artwork; not a galaxy measurement |

The source files were supplied in `C:\Users\mithu\Downloads\` and copied into the frontend public asset directory. The application should label these as illustrative when context could confuse them with scientific imagery.

## Scientific assets

- Real FITS sample: `sample_data/barnards_star_qr3/products/01/level2_2026W34_2A_0233_3D5_spx_l2b-v27-2026-243.fits`
- Synthetic FITS fixtures: `sample_data/synthetic_demo/`
- Calibration and response samples are documented in `docs/real_data_audit.md` and README sections.

Scientific imagery shown in the Image Explorer must come from API previews of persisted FITS products, with product ID, hash and observation metadata available.

## Icons and controls

The current frontend uses text/Unicode markers for some navigation symbols and native controls; no separate icon package is currently required. A Stitch export should not introduce emoji as structural icons without an explicit, accessible icon system decision.
