# Design constraints for a Stitch redesign

## Must preserve

- React/Vite frontend and FastAPI integration boundaries.
- Existing endpoint paths and response semantics.
- Investigation ID context across workspaces.
- Provenance, timestamps, hashes, units, uncertainties and quality flags.
- Real versus synthetic distinction.
- `UNTESTABLE`, `INCONCLUSIVE` and `CONTRADICTED` semantics.
- Image previews as display transformations, never source scientific values.
- Separate Planetary Computer Earth-observation workspace.
- Streamlit fallback and Python scientific engine.
- Keyboard focus, readable contrast, responsive layouts and reduced motion.

## Must not change

- Scientific calculations or Compatibility Gate logic.
- FITS parsing or storage formats.
- API contracts or identifier validation.
- Scientific source identities or measurements.
- Missing metadata handling by inventing values.
- Synthetic fixtures presented as real observations.
- External STAC imagery passed into astronomical analysis.

## Integration expectations

Stitch output should be treated as a visual/component specification. Exported markup must be translated into the existing React component tree, with real API data mapped into the visual states. Do not paste static sample values into production components. Test empty, loading, error, partial-success and UNTESTABLE states before replacing existing screens.
