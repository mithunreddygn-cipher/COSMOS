# COSMOS product brief

COSMOS is an evidence-driven astronomical investigation platform: **The Engine That Investigates What Remains Unexplained.** It helps researchers move from uploaded or archive-sourced observations to traceable scientific evidence, conservative analyses, hypotheses and reproducible reports.

## Users

- Astronomers and scientific researchers inspecting FITS observations.
- Analysts reviewing source measurements, uncertainty and compatibility.
- Students or beginners who need a guided investigation path without hiding scientific limitations.
- Reviewers who need provenance, hashes, methods and report snapshots.

## Product philosophy

Every anomaly is a question. Every observation is evidence. Every explanation is a hypothesis. The interface must distinguish authentic observations, computed quantities, user hypotheses and conclusions.

## Core workflow

**EXPLORE → ANALYZE → INVESTIGATE → REPORT**

The current frontend is a React/Vite application with a persistent workspace shell. The Python engine remains authoritative for FITS parsing, measurements, compatibility decisions and scientific status. A Streamlit application remains the fallback interface.

## Scientific integrity

COSMOS preserves uncertainty, quality flags, missing metadata, SHA-256 provenance and `UNTESTABLE` states. Synthetic demonstrations are explicitly labelled and must never be presented as real observations. Missing evidence is not treated as a negative result. Track IDs are association labels, not astronomical identities.
