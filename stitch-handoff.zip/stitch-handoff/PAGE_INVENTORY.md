# Frontend page and workspace inventory

The current React frontend is primarily composed in `frontend/src/main.tsx`; there is no React Router route tree. Navigation is client-side state (`view`) and does not reload the page.

| Destination | Purpose | Current implementation |
|---|---|---|
| Mission Control | Entry point, backend status, upload actions, progress and evidence orbit | Hero, upload controls, synthetic-demo action, status panels |
| Investigation Summary | Combined observation, compatibility, source and timeline overview | Existing `AnalysisWorkspace` |
| Image Explorer | Select persisted product/HDU/layer and inspect an authentic preview | Product/HDU requests, preview endpoint, provenance and zoom controls |
| Observations | Observation inventory and metadata | `ResultPanels` observation panel |
| Detected Sources | Backend-derived source measurements | `ResultPanels` measurement panel; empty when no measurements |
| Temporal Analysis | Flux/time measurements and periodicity result | `TemporalWorkspace`; backend results only |
| Spectral Analysis | Flux/wavelength points and calibration state | `SpectralWorkspace`; displays available points only |
| Spatial Analysis | WCS-aware positions, morphology and associations | `SpatialWorkspace`; rejects invalid celestial coordinates |
| Data Readiness | Compatibility and scientific investigation overview | `AnalysisWorkspace` |
| Evidence Review | Evidence records, units, uncertainty, compatibility and provenance | `EvidenceHypothesisWorkspace` mode `evidence` |
| Hypotheses | User-authored hypothesis creation/status editing | `EvidenceHypothesisWorkspace` mode `hypotheses` |
| Hypothesis Comparison | Select hypotheses and compare shared evidence | Same component, mode `compare` |
| Scientific Reports | Generate immutable report snapshots and download formats | `PersistentInvestigationTools` |
| Report History | List persisted historical snapshots and downloads | Same report component |
| Planetary Computer | Separate Earth-observation STAC discovery workspace | `PlanetaryComputer.tsx`; separate API namespace |

## Navigation groups

Mission, Observe, Analyze, Investigate, Report and External Data groups are rendered in the sidebar. A compact Explore/Analyze/Investigate/Report tracker is also clickable. The selected investigation is held in React state and persisted locally by investigation ID.

## Known UI limitations

- The large React implementation is not split into route-level component files.
- Browser validation is environment-blocked when localhost sockets cannot be opened.
- Workspace API calls depend on an active FastAPI investigation and show empty/unavailable states when none exists.
- The frontend does not perform scientific calculations.
