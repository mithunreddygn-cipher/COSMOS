# Backend context for frontend integration

## Runtime

- FastAPI adapter: `api/app.py`
- Scientific engine: `science/pipeline.py` and related `ingest`, `detect`, `gate`, `investigate` and `report` packages.
- Local API: `http://127.0.0.1:8000`
- Health: `GET /api/v1/health`
- React default base URL: `VITE_API_BASE_URL` or `http://127.0.0.1:8000`

## Core API contracts used by React

- `POST /api/v1/investigations` — multipart FITS/table upload; returns investigation ID, status, summary, products and scientific result.
- `POST /api/v1/investigations/synthetic-demo` — explicitly labelled synthetic demonstration.
- `GET /api/v1/investigations/{id}` — recover investigation payload.
- `GET /api/v1/investigations/{id}/products` — persisted product list and manifest metadata.
- `GET /api/v1/investigations/{id}/products/{product_id}/hdus` — HDU inventory.
- `GET /api/v1/investigations/{id}/products/{product_id}/preview?extension=IMAGE` — display-derived image preview.
- `GET /api/v1/investigations/{id}/products/{product_id}/wcs` — WCS metadata.
- `GET /api/v1/investigations/{id}/products/{product_id}/download` — original FITS product.
- `GET /api/v1/investigations/{id}/evidence` — evidence catalog.
- `GET /api/v1/investigations/{id}/hypotheses/user` — user hypotheses.
- `POST/PATCH /api/v1/investigations/{id}/hypotheses/user...` — hypothesis lifecycle and evidence association.
- `POST /api/v1/investigations/{id}/hypotheses/compare` — competing-hypothesis comparison.
- `POST /api/v1/investigations/{id}/reports` — immutable report snapshot.
- `GET /api/v1/investigations/{id}/reports` and format-specific report downloads — report history and JSON/HTML/CSV.

## Result shape

Investigation responses contain `summary`, `result`, `status`, `products` and provenance. Scientific result areas include `enriched_manifest`, `fits_processing`, `detection_results`, `multi_epoch_investigation`, `source_matches`, `hypothesis_cards`, `limitations`, `report` and calibration evidence.

Detection result statuses are backend-derived. `UNTESTABLE`, `INCONCLUSIVE`, `CONTRADICTED` and positive statuses must remain distinct in the UI.

## Persistence and security

Products persist under investigation-scoped local records with generated safe filenames and SHA-256 hashes. Investigation, hypothesis and report records are persisted separately. IDs are validated; product paths are constrained to their investigation directory; uploads are chunked and bounded. The backend is intended for localhost-controlled use, not an unauthenticated public deployment.

## External data separation

Planetary Computer routes live under `/api/v1/external/planetary-computer/`. Sentinel/STAC Earth-observation products must never be passed to the SPHEREx astronomical pipeline or presented as astronomical evidence.
