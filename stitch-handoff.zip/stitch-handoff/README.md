# COSMOS Stitch handoff

This folder packages the existing COSMOS product and engineering constraints for manual transfer into Google Stitch. It is documentation only; no existing application, API or scientific file was modified.

## Files to provide to Stitch

Provide these as the product and engineering brief:

1. `PRODUCT_BRIEF.md`
2. `PAGE_INVENTORY.md`
3. `SCIENTIFIC_WORKFLOWS.md`
4. `DESIGN_SYSTEM.md`
5. `DESIGN_CONSTRAINTS.md`
6. `ASSET_CATALOG.md`

Use `BACKEND_CONTEXT.md` when asking Stitch or a developer to map screens back to real API data. It contains endpoint and state semantics rather than visual direction.

Copy the three files from `frontend/public/assets/` as visual assets if Stitch accepts local uploads. Do not upload private datasets, credentials, environment files or records directories.

## Screenshots

The requested screenshots directory is reserved at `stitch-handoff/screenshots/`. No screenshots are included because the managed environment forbids localhost socket binding and could not run the Vite/FastAPI browser session. Do not treat a static build as rendered-browser evidence.

On Windows 11, start the app with:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\start-cosmos-local.ps1
```

Then capture reference screens with:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run-cosmos-browser-tests.ps1
```

Copy only approved screenshots into this folder after actual browser execution.

## Integrating a Stitch export later

1. Keep the existing `frontend/src/main.tsx` data-flow and API calls as the source of truth.
2. Extract Stitch visual sections into React components rather than replacing the scientific engine.
3. Map loading, empty, error, partial-success and UNTESTABLE states before adding visual polish.
4. Keep FITS previews, charts and tables driven by backend responses.
5. Verify TypeScript, production build, API regression tests and browser workflows.
6. Review responsive behavior and provenance visibility at every workspace.

## Incomplete or blocked validation

- Browser screenshot capture is not present in this handoff because local services cannot bind sockets in the managed environment.
- Real SPHEREx validation remains limited; one authentic product does not establish multi-epoch results.
- Full scientific production readiness is not claimed.
