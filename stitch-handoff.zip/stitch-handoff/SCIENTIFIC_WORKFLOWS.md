# Scientific workflows

## Explore

Users upload local FITS/table products or use the separately scoped IRSA/Planetary Computer discovery tools. Ingestion identifies supported formats, hashes files, inspects metadata and reports duplicates, unsupported files and missing information. IRSA failures, empty results and invalid responses remain separate outcomes.

## Analyze

The Python pipeline inspects every FITS HDU and may extract IMAGE, FLAGS, VARIANCE, ZODI, PSF/ePSF and WCS-WAVE roles. It preserves native dtype and byte order internally, derives WCS coordinates when valid, masks configured quality flags, estimates backgrounds and performs conservative source detection and aperture photometry. Morphology is image-plane observed shape; it is not PSF-deconvolved classification.

Temporal screening requires compatible epochs, valid timestamps, uncertainties and a `RUNNABLE` Compatibility Gate. Spectral screening requires compatible wavelength/response evidence and adequate samples. Spatial comparison requires compatible WCS positions and uncertainties. Proper motion requires multiple compatible positions; periodicity requires sufficient valid epochs. Missing prerequisites produce `UNTESTABLE`.

## Investigate

Evidence records preserve category, observed/derived value, units, uncertainty, quality, compatibility, observation/product provenance and limitations. User hypotheses are persisted independently from pipeline-generated assessment cards. Evidence can be supporting, contradictory, inconclusive or unresolved. Comparison exposes shared and unique evidence without selecting a winner.

## Report

Reports preserve a snapshot of the investigation, methods, measurements, evidence, hypotheses, provenance and limitations. JSON, HTML and CSV are available. Historical reports must display their stored snapshot rather than regenerate from current state.

## Synthetic versus real

`sample_data/synthetic_demo/` is a software fixture and must be labelled synthetic. The saved real SPHEREx sample is under `sample_data/barnards_star_qr3/`; one real product does not establish multi-epoch scientific conclusions. Decorative supplied PNGs are visual assets only and are not scientific observations.
